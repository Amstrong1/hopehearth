<div class="p-8">
    <p><strong><u>Détail de l'expéditeur</u></strong></p>
    <p>
        <strong>Objet : </strong>{{ $data['subject'] }}
    </p>
    <p>
        <strong>Name : </strong>{{ $data['name'] }}
    </p>
    <p>
        <strong>Email : </strong>{{ $data['email'] }}
    </p>
    <p>
        <strong>Phone : </strong>{{ $data['phone'] }}
    </p>
    <p>
        <strong>Message : </strong>{{ $data['message'] }}
    </p>
</div>
