<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="relative bg-slate-50">
        <!-- Header -->
        <div class="relative bg-pink-600 pb-32 pt-12">
        </div>
        <div class="px-4 md:px-10 w-full -m-24">
            <div class="flex flex-wrap">
                <div class="w-full lg:w-8/12 px-4 mx-auto">
                    <div
                        class="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-slate-100 border-0">
                        <div class="rounded-t mb-0 px-6 py-6">
                            <div class="text-center flex justify-between">
                                <h6 class="text-slate-700 text-xl font-bold">
                                    Confirmer ma donation
                                </h6>
                            </div>
                        </div>
                        <div class="flex-auto px-4 lg:px-10 py-10 pt-0">
                            <form method="post" action="<?php echo e(route('gift.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="validrequest_id" value="<?php echo e($id); ?>">
                                <div class="flex flex-wrap">
                                    <div class="w-full md:w-6/12 px-4">
                                        <div class="relative w-full mb-3">
                                            <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                htmlFor="grid-password">
                                                Prenom
                                            </label>
                                            <input type="email" name="donor_fname"
                                                class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" />
                                        </div>
                                    </div>
                                    <div class="w-full md:w-6/12 px-4">
                                        <div class="relative w-full mb-3">
                                            <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                htmlFor="grid-password">
                                                Email
                                            </label>
                                            <input type="text" name="donor_email"
                                                class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" />
                                        </div>
                                    </div>
                                    <div class="w-full md:w-6/12 px-4">
                                        <div class="relative w-full mb-3">
                                            <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                htmlFor="grid-password">
                                                Tel
                                            </label>
                                            <input type="tel" name="donor_tel"
                                                class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" />
                                        </div>
                                    </div>
                                    <?php if($amount !== 'custom'): ?>
                                        <div class="w-full md:w-6/12 px-4">
                                            <div class="relative w-full mb-3">
                                                <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                    htmlFor="grid-password">
                                                    Montant
                                                </label>
                                                <input type="number" name="amount" value="<?php echo e($amount); ?>"
                                                    readonly
                                                    class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" />
                                            </div>
                                        </div>
                                        <div class="w-full px-4">
                                            <div class="relative w-full mb-3">
                                                <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                    htmlFor="grid-password">
                                                    Message
                                                </label>
                                                <textarea name="msg" maxlength="155"
                                                    class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150">
                                                </textarea>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($amount == 'custom'): ?>
                                        
                                        <div class="relative mb-3 px-4 w-6/12">
                                            <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                htmlFor="grid-password">
                                                Montant
                                            </label>
                                            <input type="number" name="amount"
                                                class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" />
                                        </div>

                                        <div class="relative w-full mb-3 px-4">
                                            <label class="block uppercase text-slate-600 text-xs font-bold mb-2"
                                                htmlFor="grid-password">
                                                Message
                                            </label>
                                            <textarea name="msg" maxlength="155"
                                                class="border-0 px-3 py-3 placeholder-slate-300 text-slate-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150">
                                                </textarea>
                                        </div>
                                        
                                    <?php endif; ?>
                                </div>

                                

                                <div class="mt-4 w-full px-4">
                                    <button type="submit"
                                        class="w-full bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-md p-4 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                                        type="button">
                                        Confirmer
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\nonvizor\resources\views/app/gift/create.blade.php ENDPATH**/ ?>