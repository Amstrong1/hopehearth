<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="relative bg-slate-50">

        <div class="relative bg-pink-600 md:pt-32 pb-32 pt-12 md:sticky top-0">
            <div class="px-4 md:px-10 mx-auto w-full text-center text-white">
                <h1 class="text-2xl font-bold">Detail de la demande</h1>
            </div>
        </div>
        <div class="px-4 md:px-10 mx-auto w-full -mt-24">
            <div class="flex flex-wrap">
                <div class="w-full md:w-1/3 px-4">
                    <div
                        class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg mt-4 md:sticky top-10">
                        <div class="p-6">
                            <div class="mt-6 lg:px-4">
                                <h3 class=" text-lg font-semibold leading-normal mb-2 text-slate-700">
                                    <?php echo e($patient->prenom); ?>

                                </h3>
                                <div class="text-slate-600 my-2">
                                    <span class="font-semibold mb-2 text-slate-700">Code de la demande :
                                    </span><?php echo e($patient->code); ?>

                                </div>
                                <div class="text-slate-600 my-2">
                                    <span class="font-semibold mb-2 text-slate-700">
                                        Profession :
                                    </span>
                                    <?php echo e($patient->career); ?>

                                </div>
                                <div class="text-slate-600 my-2">
                                    <span class="font-semibold mb-2 text-slate-700">
                                        Hopital :
                                    </span>
                                    <?php echo e($patient->hospital->name); ?>

                                </div>
                                <div class="text-slate-600 my-2">
                                    <div class="justify-between">
                                        <span class="font-semibold mb-2 text-slate-700">
                                            Sexe : </span>
                                        <?php echo e($patient->sex); ?>

                                    </div>
                                </div>
                                <div class="text-slate-600 my-2">
                                    <div class="justify-between"><span class="font-semibold mb-2 text-slate-700">Age
                                            :
                                        </span><?php echo e(dateDiff(date('Y-m-d'), $patient->birthday)); ?>

                                        <?php echo e(' ans'); ?>

                                    </div>
                                </div>
                                <div class="text-slate-600 my-2">
                                    <span class="font-semibold mb-2 text-slate-700">
                                        Traitement :
                                    </span>
                                    <?php echo e($patient->treatment); ?>

                                </div>
                                <div class="text-slate-600 my-2">
                                    <span class="font-semibold mb-2 text-slate-700">
                                        Coût :
                                    </span>
                                    <?php echo e(number_format($patient->cost, 0, '', ' ')); ?>

                                </div>
                                <div class="text-slate-600 my-2">
                                    <?php
                                        $gift = DB::table('gifts')
                                            ->select(DB::raw('SUM(amount) as total'))
                                            ->where('validrequest_id', $patient->request_id)
                                            ->first();
                                    ?>
                                    <span class="font-semibold mb-2 text-slate-700">
                                        Déja recu :
                                    </span>
                                    <?php echo e(number_format($gift->total, 0, '', ' ')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="w-full md:w-2/3 px-4">
                    <div
                        class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg mt-4">
                        <div class="p-6">
                            <h3
                                class="text:lg font-semibold leading-normal mb-2 text-slate-700 uppercase text-center">
                                Offrir une carte cadeau
                            </h3>
                            <a href="<?php echo e(route('gift.create', [$patient->id, 100])); ?>">
                                <button type="button"
                                    class="bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-sm px-6 py-4 rounded-lg shadow hover:shadow-md outline-none focus:outline-none ease-linear m-4 transition-all duration-150">
                                    <i class="fas fa-gift"></i>
                                    100
                                </button>
                            </a>
                            <a href="<?php echo e(route('gift.create', [$patient->id, 200])); ?>">
                                <button type="button"
                                    class="bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-sm px-6 py-4 rounded-lg shadow hover:shadow-md outline-none focus:outline-none ease-linear m-4 transition-all duration-150">
                                    <i class="fas fa-gift"></i>
                                    200
                                </button>
                            </a>
                            <a href="<?php echo e(route('gift.create', [$patient->id, 500])); ?>">
                                <button type="button"
                                    class="bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-sm px-6 py-4 rounded-lg shadow hover:shadow-md outline-none focus:outline-none ease-linear m-4 transition-all duration-150">
                                    <i class="fas fa-gift"></i>
                                    500
                                </button>
                            </a>
                            <a href="<?php echo e(route('gift.create', [$patient->id, 1000])); ?>">
                                <button type="button"
                                    class="bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-sm px-6 py-4 rounded-lg shadow hover:shadow-md outline-none focus:outline-none ease-linear m-4 transition-all duration-150">
                                    <i class="fas fa-gift"></i>
                                    1000
                                </button>
                            </a>
                            <a href="<?php echo e(route('gift.create', [$patient->id, 2000])); ?>">
                                <button type="button"
                                    class="bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-sm px-6 py-4 rounded-lg shadow hover:shadow-md outline-none focus:outline-none ease-linear m-4 transition-all duration-150">
                                    <i class="fas fa-gift"></i>
                                    2000
                                </button>
                            </a>
                            <a href="<?php echo e(route('gift.create', [$patient->id, 'custom'])); ?>">
                                <button type="button"
                                    class="bg-pink-500 text-white active:bg-pink-600 font-bold uppercase text-sm px-6 py-4 rounded-lg shadow hover:shadow-md outline-none focus:outline-none m-4 ease-linear transition-all duration-150">
                                    <i class="fas fa-gift"></i>
                                    Autres
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\nonvizor\resources\views/app/gift/show.blade.php ENDPATH**/ ?>