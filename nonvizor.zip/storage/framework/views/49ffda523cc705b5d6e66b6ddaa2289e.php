<div class="container">
    <p><strong><u>Détail de l'expéditeur</u></strong></p>
    <p>
        <strong>Objet : </strong><?php echo e($data['subject']); ?>

    </p>
    <p>
        <strong>Name : </strong><?php echo e($data['name']); ?>

    </p>
    <p>
        <strong>Email : </strong><?php echo e($data['email']); ?>

    </p>
    <p>
        <strong>Phone : </strong><?php echo e($data['phone']); ?>

    </p>
    <p>
        <strong>Message : </strong><?php echo e($data['message']); ?>

    </p>
</div>
<?php /**PATH C:\xampp\htdocs\nonvizor\resources\views/mail.blade.php ENDPATH**/ ?>